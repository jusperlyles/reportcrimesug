
-- ============================================
-- 1. UTILITY FUNCTION FOR TIMESTAMPS
-- ============================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- ============================================
-- 2. USER ROLES (enum + table)
-- ============================================
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles" ON public.user_roles
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert roles" ON public.user_roles
  FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update roles" ON public.user_roles
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete roles" ON public.user_roles
  FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- ============================================
-- 3. PROFILES TABLE
-- ============================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  language TEXT DEFAULT 'en',
  nin TEXT,
  district TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles" ON public.profiles
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 4. POLICE STATIONS
-- ============================================
CREATE TABLE public.police_stations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  district TEXT NOT NULL,
  address TEXT,
  phone TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  region TEXT,
  station_type TEXT DEFAULT 'police_station',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.police_stations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view stations" ON public.police_stations
  FOR SELECT USING (true);

CREATE POLICY "Admins can insert stations" ON public.police_stations
  FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update stations" ON public.police_stations
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete stations" ON public.police_stations
  FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- ============================================
-- 5. CRIME REPORTS
-- ============================================
CREATE TYPE public.report_status AS ENUM ('pending', 'under_review', 'investigating', 'resolved', 'dismissed');

CREATE TABLE public.crime_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reference_number TEXT UNIQUE NOT NULL DEFAULT ('CR-' || UPPER(SUBSTR(gen_random_uuid()::text, 1, 8))),
  crime_type TEXT NOT NULL,
  description TEXT NOT NULL,
  location TEXT,
  district TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  date_of_incident TIMESTAMP WITH TIME ZONE,
  status report_status NOT NULL DEFAULT 'pending',
  station_id UUID REFERENCES public.police_stations(id),
  is_anonymous BOOLEAN DEFAULT false,
  admin_notes TEXT,
  media_urls TEXT[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.crime_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own reports" ON public.crime_reports
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all reports" ON public.crime_reports
  FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can create reports" ON public.crime_reports
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own pending reports" ON public.crime_reports
  FOR UPDATE USING (auth.uid() = user_id AND status = 'pending');

CREATE POLICY "Admins can update all reports" ON public.crime_reports
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_crime_reports_updated_at
  BEFORE UPDATE ON public.crime_reports
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 6. MISSING PERSONS
-- ============================================
CREATE TABLE public.missing_persons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL NOT NULL,
  reference_number TEXT UNIQUE NOT NULL DEFAULT ('MP-' || UPPER(SUBSTR(gen_random_uuid()::text, 1, 8))),
  full_name TEXT NOT NULL,
  age INTEGER,
  gender TEXT,
  description TEXT NOT NULL,
  last_seen_location TEXT,
  last_seen_date TIMESTAMP WITH TIME ZONE,
  district TEXT,
  contact_phone TEXT,
  contact_name TEXT,
  photo_url TEXT,
  status report_status NOT NULL DEFAULT 'pending',
  is_found BOOLEAN DEFAULT false,
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.missing_persons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view missing persons" ON public.missing_persons
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can report missing persons" ON public.missing_persons
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own missing person reports" ON public.missing_persons
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can update all missing persons" ON public.missing_persons
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_missing_persons_updated_at
  BEFORE UPDATE ON public.missing_persons
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 7. MISSING PROPERTY
-- ============================================
CREATE TABLE public.missing_property (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL NOT NULL,
  reference_number TEXT UNIQUE NOT NULL DEFAULT ('MPR-' || UPPER(SUBSTR(gen_random_uuid()::text, 1, 8))),
  item_type TEXT NOT NULL,
  item_description TEXT NOT NULL,
  serial_number TEXT,
  last_seen_location TEXT,
  last_seen_date TIMESTAMP WITH TIME ZONE,
  district TEXT,
  status report_status NOT NULL DEFAULT 'pending',
  is_found BOOLEAN DEFAULT false,
  photo_url TEXT,
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.missing_property ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view missing property" ON public.missing_property
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can report missing property" ON public.missing_property
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own property reports" ON public.missing_property
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can update all property reports" ON public.missing_property
  FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_missing_property_updated_at
  BEFORE UPDATE ON public.missing_property
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- 8. NOTIFICATIONS
-- ============================================
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  link TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON public.notifications
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "System can create notifications" ON public.notifications
  FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR auth.uid() = user_id);

-- ============================================
-- 9. STORAGE BUCKETS
-- ============================================
INSERT INTO storage.buckets (id, name, public) VALUES ('evidence', 'evidence', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);
INSERT INTO storage.buckets (id, name, public) VALUES ('missing-photos', 'missing-photos', true);

CREATE POLICY "Authenticated users can upload evidence" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'evidence' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view evidence" ON storage.objects
  FOR SELECT USING (bucket_id = 'evidence');

CREATE POLICY "Users can upload avatars" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Anyone can view avatars" ON storage.objects
  FOR SELECT USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload missing photos" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'missing-photos' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view missing photos" ON storage.objects
  FOR SELECT USING (bucket_id = 'missing-photos');

-- ============================================
-- 10. SEED POLICE STATIONS
-- ============================================
INSERT INTO public.police_stations (name, district, address, phone, region, station_type) VALUES
  ('Central Police Station', 'Kampala', 'Plot 2, Pilkington Road', '+256-414-233771', 'Central', 'police_station'),
  ('Jinja Road Police Station', 'Kampala', 'Jinja Road', '+256-414-259938', 'Central', 'police_station'),
  ('Old Kampala Police Station', 'Kampala', 'Old Kampala Road', '+256-414-271684', 'Central', 'police_station'),
  ('Katwe Police Station', 'Kampala', 'Katwe', '+256-414-271100', 'Central', 'police_station'),
  ('Wandegeya Police Station', 'Kampala', 'Bombo Road', '+256-414-540185', 'Central', 'police_station'),
  ('Jinja Central Police Station', 'Jinja', 'Main Street', '+256-434-120233', 'Eastern', 'police_station'),
  ('Mbale Police Station', 'Mbale', 'Republic Street', '+256-454-433001', 'Eastern', 'police_station'),
  ('Gulu Central Police Station', 'Gulu', 'Acholi Road', '+256-471-432100', 'Northern', 'police_station'),
  ('Mbarara Police Station', 'Mbarara', 'High Street', '+256-485-420111', 'Western', 'police_station'),
  ('Fort Portal Police Station', 'Fort Portal', 'Lugard Road', '+256-483-422100', 'Western', 'police_station');
