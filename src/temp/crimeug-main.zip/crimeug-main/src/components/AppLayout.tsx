import { ReactNode, useState } from "react";
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useI18n } from "@/contexts/I18nContext";
import {
  Home, FileText, Users, MapPin, Search, Bell, Settings, LogOut,
  Menu, X, Shield, Scale, HelpCircle, Package, ChevronRight,
  BarChart3
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface NavItem {
  label: string;
  path: string;
  icon: ReactNode;
  adminOnly?: boolean;
}

export default function AppLayout() {
  const { user, profile, isAdmin, signOut } = useAuth();
  const { t } = useI18n();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems: NavItem[] = [
    { label: t("nav.home"), path: "/dashboard", icon: <Home className="h-5 w-5" /> },
    { label: t("nav.report"), path: "/report-crime", icon: <FileText className="h-5 w-5" /> },
    { label: t("nav.missing"), path: "/missing-persons", icon: <Users className="h-5 w-5" /> },
    { label: t("nav.property"), path: "/missing-property", icon: <Package className="h-5 w-5" /> },
    { label: t("nav.stations"), path: "/stations", icon: <MapPin className="h-5 w-5" /> },
    { label: t("nav.reports"), path: "/my-reports", icon: <BarChart3 className="h-5 w-5" /> },
    { label: t("nav.laws"), path: "/laws", icon: <Scale className="h-5 w-5" /> },
    { label: t("nav.help"), path: "/help", icon: <HelpCircle className="h-5 w-5" /> },
    { label: t("nav.notifications"), path: "/notifications", icon: <Bell className="h-5 w-5" /> },
    { label: t("nav.settings"), path: "/settings", icon: <Settings className="h-5 w-5" /> },
  ];

  const adminItems: NavItem[] = [
    { label: t("admin.dashboard"), path: "/admin", icon: <Shield className="h-5 w-5" />, adminOnly: true },
    { label: t("admin.users"), path: "/admin/users", icon: <Users className="h-5 w-5" />, adminOnly: true },
    { label: t("admin.pending"), path: "/admin/pending", icon: <FileText className="h-5 w-5" />, adminOnly: true },
    { label: t("admin.reports"), path: "/admin/reports", icon: <BarChart3 className="h-5 w-5" />, adminOnly: true },
  ];

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
        <div className="p-6 border-b border-sidebar-border">
          <h1 className="text-lg font-semibold text-sidebar-foreground">🇺🇬 {t("app.title")}</h1>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                isActive(item.path)
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
          {isAdmin && (
            <>
              <div className="pt-4 pb-2 px-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/40">Admin</p>
              </div>
              {adminItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                    isActive(item.path)
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}
                >
                  {item.icon}
                  {item.label}
                </Link>
              ))}
            </>
          )}
        </nav>
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-8 w-8 rounded-full bg-sidebar-accent flex items-center justify-center text-sm font-medium">
              {profile?.full_name?.charAt(0) || "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{profile?.full_name || "User"}</p>
              <p className="text-xs text-sidebar-foreground/50 truncate">{user?.email}</p>
            </div>
          </div>
          <Button
            variant="ghost"
            className="w-full justify-start text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
            onClick={handleSignOut}
          >
            <LogOut className="h-4 w-4 mr-2" />
            {t("nav.logout")}
          </Button>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-foreground/20" onClick={() => setSidebarOpen(false)} />
          <aside className="fixed left-0 top-0 bottom-0 w-72 bg-sidebar text-sidebar-foreground z-50 animate-fade-in">
            <div className="p-4 flex items-center justify-between border-b border-sidebar-border">
              <h1 className="text-lg font-semibold">🇺🇬 {t("app.title")}</h1>
              <button onClick={() => setSidebarOpen(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="py-4 px-3 space-y-1 overflow-y-auto" style={{ maxHeight: "calc(100vh - 120px)" }}>
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                    isActive(item.path)
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50"
                  )}
                >
                  {item.icon}
                  {item.label}
                </Link>
              ))}
              {isAdmin && adminItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                    isActive(item.path)
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50"
                  )}
                >
                  {item.icon}
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-sidebar-border">
              <Button variant="ghost" className="w-full justify-start text-sidebar-foreground/70" onClick={handleSignOut}>
                <LogOut className="h-4 w-4 mr-2" />
                {t("nav.logout")}
              </Button>
            </div>
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-14 bg-card border-b border-border flex items-center px-4 gap-4">
          <button className="lg:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5 text-muted-foreground" />
          </button>
          <div className="flex-1">
            <div className="flex items-center text-sm text-muted-foreground">
              <Link to="/dashboard" className="hover:text-foreground">Home</Link>
              {location.pathname !== "/dashboard" && (
                <>
                  <ChevronRight className="h-3 w-3 mx-1" />
                  <span className="text-foreground font-medium capitalize">
                    {location.pathname.split("/").pop()?.replace(/-/g, " ")}
                  </span>
                </>
              )}
            </div>
          </div>
          <Link to="/notifications" className="relative">
            <Bell className="h-5 w-5 text-muted-foreground hover:text-foreground transition-colors" />
          </Link>
        </header>
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>

        {/* Mobile bottom nav */}
        <nav className="lg:hidden flex items-center justify-around bg-card border-t border-border h-16 px-2">
          {[
            { path: "/dashboard", icon: <Home className="h-5 w-5" />, label: t("nav.home") },
            { path: "/report-crime", icon: <FileText className="h-5 w-5" />, label: t("nav.report") },
            { path: "/missing-persons", icon: <Users className="h-5 w-5" />, label: t("nav.missing") },
            { path: "/notifications", icon: <Bell className="h-5 w-5" />, label: t("nav.notifications") },
            { path: "/settings", icon: <Settings className="h-5 w-5" />, label: t("nav.settings") },
          ].map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex flex-col items-center gap-1 text-xs",
                isActive(item.path) ? "text-primary" : "text-muted-foreground"
              )}
            >
              {item.icon}
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}
