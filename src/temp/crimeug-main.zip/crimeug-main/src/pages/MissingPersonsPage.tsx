import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getMissingPersons } from "@/services/api";
import { useI18n } from "@/contexts/I18nContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Users, Plus } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";

const statusColors: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-primary/10 text-primary border-primary/20",
  investigating: "bg-primary/10 text-primary border-primary/20",
  resolved: "bg-success/10 text-success border-success/20",
  dismissed: "bg-muted text-muted-foreground border-border",
};

export default function MissingPersonsPage() {
  const { t } = useI18n();
  const [persons, setPersons] = useState<Tables<"missing_persons">[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMissingPersons().then(setPersons).finally(() => setLoading(false));
  }, []);

  const filtered = persons.filter((p) =>
    p.full_name.toLowerCase().includes(search.toLowerCase()) ||
    p.description.toLowerCase().includes(search.toLowerCase()) ||
    (p.district || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">{t("nav.missing")}</h1>
          <p className="text-muted-foreground text-sm mt-1">{filtered.length} reports</p>
        </div>
        <Link to="/report-missing-person">
          <Button><Plus className="h-4 w-4 mr-2" />Report</Button>
        </Link>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          className="pl-10"
          placeholder={t("common.search")}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="text-center py-12 text-muted-foreground">{t("common.loading")}</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Users className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">{t("common.no_results")}</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filtered.map((person) => (
            <Card key={person.id} className="border border-border hover:border-primary/20 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-medium">{person.full_name}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{person.description}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      {person.age && <span>Age: {person.age}</span>}
                      {person.gender && <span>• {person.gender}</span>}
                      {person.district && <span>• {person.district}</span>}
                    </div>
                    {person.last_seen_location && (
                      <p className="text-xs text-muted-foreground mt-1">Last seen: {person.last_seen_location}</p>
                    )}
                  </div>
                  <Badge variant="outline" className={statusColors[person.status] || ""}>
                    {person.status.replace("_", " ")}
                  </Badge>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                  <span className="text-xs text-muted-foreground">Ref: {person.reference_number}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(person.created_at).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
