import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Scale, Shield, UserCheck, AlertTriangle, Phone } from "lucide-react";

const sections = [
  {
    title: "Your Constitutional Rights",
    icon: Shield,
    items: [
      "Right to life (Article 22)",
      "Right to personal liberty (Article 23)",
      "Right to fair hearing (Article 28)",
      "Freedom from torture and cruel treatment (Article 24)",
      "Right to privacy (Article 27)",
      "Freedom of expression (Article 29)",
      "Right to education (Article 30)",
    ],
  },
  {
    title: "Rights When Arrested",
    icon: UserCheck,
    items: [
      "Right to be informed of the reason for arrest",
      "Right to a lawyer of your choice",
      "Right to be brought before court within 48 hours",
      "Right to apply for bail",
      "Right to remain silent",
      "Right to humane treatment while in custody",
    ],
  },
  {
    title: "Important Laws",
    icon: Scale,
    items: [
      "Penal Code Act - Defines criminal offences",
      "Police Act - Regulates police operations",
      "Evidence Act - Rules on admissible evidence",
      "Trial on Indictments Act - Court procedures",
      "Children Act - Protection of children's rights",
      "Domestic Violence Act 2010",
      "Anti-Corruption Act 2009",
    ],
  },
  {
    title: "Reporting Violations",
    icon: AlertTriangle,
    items: [
      "Uganda Human Rights Commission: 0800-100-011",
      "Inspector General of Police: +256-414-233-771",
      "Uganda Law Society: +256-414-342-424",
      "Legal Aid Project: +256-414-342-431",
    ],
  },
];

export default function LawsPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">Laws & Rights</h1>
      <p className="text-muted-foreground">Know your rights under the Constitution of Uganda and relevant laws.</p>
      <div className="space-y-4">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <Card key={section.title} className="border border-border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Icon className="h-5 w-5 text-primary" />
                  {section.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {section.items.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <Card className="border-destructive/20 bg-destructive/5">
        <CardContent className="py-4 flex items-center gap-3">
          <Phone className="h-5 w-5 text-destructive" />
          <div>
            <p className="font-medium text-sm">Emergency: Call 999 or 112</p>
            <p className="text-xs text-muted-foreground">Available 24/7 for immediate assistance</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
