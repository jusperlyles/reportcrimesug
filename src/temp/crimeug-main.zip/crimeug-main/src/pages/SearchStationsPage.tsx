import { useEffect, useState } from "react";
import { getPoliceStations } from "@/services/api";
import { useI18n } from "@/contexts/I18nContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Phone } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";

export default function SearchStationsPage() {
  const { t } = useI18n();
  const [stations, setStations] = useState<Tables<"police_stations">[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getPoliceStations().then(setStations).finally(() => setLoading(false));
  }, []);

  const filtered = stations.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.district.toLowerCase().includes(search.toLowerCase()) ||
    (s.region || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">{t("nav.stations")}</h1>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-10" placeholder={t("common.search")} value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">{t("common.loading")}</div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {filtered.map((station) => (
            <Card key={station.id} className="border border-border">
              <CardContent className="p-4">
                <h3 className="font-medium">{station.name}</h3>
                <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5" />
                  <span>{station.address || station.district}</span>
                </div>
                {station.phone && (
                  <a href={`tel:${station.phone}`} className="flex items-center gap-1 mt-1 text-sm text-primary hover:underline">
                    <Phone className="h-3.5 w-3.5" />
                    <span>{station.phone}</span>
                  </a>
                )}
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-muted px-2 py-0.5 rounded">{station.district}</span>
                  {station.region && <span className="text-xs bg-muted px-2 py-0.5 rounded">{station.region}</span>}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
