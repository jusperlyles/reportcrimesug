import { useEffect, useState } from "react";
import { getAllCrimeReports, getAllMissingPersons, getAllMissingProperty, updateCrimeReport, updateMissingPerson, updateMissingProperty } from "@/services/api";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, X, Clock } from "lucide-react";
import { toast } from "sonner";
import type { Tables } from "@/integrations/supabase/types";

type PendingItem = {
  id: string;
  type: "crime" | "person" | "property";
  title: string;
  description: string;
  reference: string;
  date: string;
};

export default function PendingRequestsPage() {
  const [items, setItems] = useState<PendingItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    const [crimes, persons, property] = await Promise.all([
      getAllCrimeReports(),
      getAllMissingPersons(),
      getAllMissingProperty(),
    ]);

    const pending: PendingItem[] = [
      ...crimes.filter((c) => c.status === "pending").map((c) => ({
        id: c.id, type: "crime" as const, title: c.crime_type,
        description: c.description, reference: c.reference_number, date: c.created_at,
      })),
      ...persons.filter((p) => p.status === "pending").map((p) => ({
        id: p.id, type: "person" as const, title: p.full_name,
        description: p.description, reference: p.reference_number, date: p.created_at,
      })),
      ...property.filter((p) => p.status === "pending").map((p) => ({
        id: p.id, type: "property" as const, title: p.item_type,
        description: p.item_description, reference: p.reference_number, date: p.created_at,
      })),
    ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    setItems(pending);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleAction = async (item: PendingItem, status: "under_review" | "dismissed") => {
    try {
      if (item.type === "crime") await updateCrimeReport(item.id, { status });
      else if (item.type === "person") await updateMissingPerson(item.id, { status });
      else await updateMissingProperty(item.id, { status });
      toast.success(`Report ${status === "under_review" ? "approved" : "dismissed"}`);
      fetchData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const typeLabels = { crime: "Crime Report", person: "Missing Person", property: "Missing Property" };
  const typeColors = { crime: "bg-destructive/10 text-destructive", person: "bg-warning/10 text-warning", property: "bg-primary/10 text-primary" };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">Pending Requests</h1>
        <p className="text-sm text-muted-foreground mt-1">{items.length} items awaiting review</p>
      </div>
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading...</div>
      ) : items.length === 0 ? (
        <div className="text-center py-12">
          <Clock className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">No pending requests</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <Card key={item.id} className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className={typeColors[item.type]}>{typeLabels[item.type]}</Badge>
                      <span className="text-xs text-muted-foreground">{item.reference}</span>
                    </div>
                    <h3 className="font-medium">{item.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{item.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">{new Date(item.date).toLocaleString()}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleAction(item, "under_review")}>
                      <Check className="h-4 w-4 mr-1" />Approve
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => handleAction(item, "dismissed")}>
                      <X className="h-4 w-4 mr-1" />Dismiss
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
