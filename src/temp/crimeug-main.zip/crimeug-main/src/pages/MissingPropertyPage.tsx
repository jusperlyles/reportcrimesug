import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getMissingProperty } from "@/services/api";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Package, Plus } from "lucide-react";
import type { Tables } from "@/integrations/supabase/types";

const statusColors: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-primary/10 text-primary border-primary/20",
  investigating: "bg-primary/10 text-primary border-primary/20",
  resolved: "bg-success/10 text-success border-success/20",
  dismissed: "bg-muted text-muted-foreground border-border",
};

export default function MissingPropertyPage() {
  const [items, setItems] = useState<Tables<"missing_property">[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMissingProperty().then(setItems).finally(() => setLoading(false));
  }, []);

  const filtered = items.filter((p) =>
    p.item_type.toLowerCase().includes(search.toLowerCase()) ||
    p.item_description.toLowerCase().includes(search.toLowerCase()) ||
    (p.district || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Lost & Found Property</h1>
          <p className="text-muted-foreground text-sm mt-1">{filtered.length} reports</p>
        </div>
        <Link to="/report-missing-property">
          <Button><Plus className="h-4 w-4 mr-2" />Report</Button>
        </Link>
      </div>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-10" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Package className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
          <p className="text-muted-foreground">No results found</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {filtered.map((item) => (
            <Card key={item.id} className="border border-border hover:border-primary/20 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <h3 className="font-medium">{item.item_type}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{item.item_description}</p>
                    {item.serial_number && <p className="text-xs text-muted-foreground mt-1">S/N: {item.serial_number}</p>}
                    {item.district && <p className="text-xs text-muted-foreground mt-1">{item.district}</p>}
                  </div>
                  <Badge variant="outline" className={statusColors[item.status]}>{item.status.replace("_", " ")}</Badge>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
                  <span className="text-xs text-muted-foreground">Ref: {item.reference_number}</span>
                  <span className="text-xs text-muted-foreground">{new Date(item.created_at).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
