import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { getCrimeReports, getMissingPersons, getMissingProperty } from "@/services/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Tables } from "@/integrations/supabase/types";

const statusColors: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-primary/10 text-primary border-primary/20",
  investigating: "bg-primary/10 text-primary border-primary/20",
  resolved: "bg-success/10 text-success border-success/20",
  dismissed: "bg-muted text-muted-foreground border-border",
};

export default function MyReportsPage() {
  const { user } = useAuth();
  const [crimes, setCrimes] = useState<Tables<"crime_reports">[]>([]);
  const [persons, setPersons] = useState<Tables<"missing_persons">[]>([]);
  const [property, setProperty] = useState<Tables<"missing_property">[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getCrimeReports(user.id),
      getMissingPersons().then((all) => all.filter((p) => p.user_id === user.id)),
      getMissingProperty().then((all) => all.filter((p) => p.user_id === user.id)),
    ]).then(([c, p, pr]) => { setCrimes(c); setPersons(p); setProperty(pr); }).finally(() => setLoading(false));
  }, [user]);

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  const ReportCard = ({ ref_num, title, status, date, desc }: { ref_num: string; title: string; status: string; date: string; desc: string }) => (
    <Card className="border border-border">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-medium">{title}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{desc}</p>
          </div>
          <Badge variant="outline" className={statusColors[status] || ""}>{status.replace("_", " ")}</Badge>
        </div>
        <div className="flex justify-between mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
          <span>Ref: {ref_num}</span>
          <span>{new Date(date).toLocaleDateString()}</span>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">My Reports</h1>
      <Tabs defaultValue="crimes">
        <TabsList>
          <TabsTrigger value="crimes">Crime Reports ({crimes.length})</TabsTrigger>
          <TabsTrigger value="persons">Missing Persons ({persons.length})</TabsTrigger>
          <TabsTrigger value="property">Missing Property ({property.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="crimes" className="space-y-3 mt-4">
          {crimes.length === 0 ? <p className="text-muted-foreground text-center py-8">No crime reports yet</p> :
            crimes.map((c) => <ReportCard key={c.id} ref_num={c.reference_number} title={c.crime_type} status={c.status} date={c.created_at} desc={c.description} />)}
        </TabsContent>
        <TabsContent value="persons" className="space-y-3 mt-4">
          {persons.length === 0 ? <p className="text-muted-foreground text-center py-8">No missing person reports yet</p> :
            persons.map((p) => <ReportCard key={p.id} ref_num={p.reference_number} title={p.full_name} status={p.status} date={p.created_at} desc={p.description} />)}
        </TabsContent>
        <TabsContent value="property" className="space-y-3 mt-4">
          {property.length === 0 ? <p className="text-muted-foreground text-center py-8">No missing property reports yet</p> :
            property.map((p) => <ReportCard key={p.id} ref_num={p.reference_number} title={p.item_type} status={p.status} date={p.item_description} desc={p.item_description} />)}
        </TabsContent>
      </Tabs>
    </div>
  );
}
