import { useEffect, useState } from "react";
import { getAllUsers, getUserRoles, setUserRole, removeUserRole } from "@/services/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Shield, ShieldOff } from "lucide-react";
import { toast } from "sonner";
import type { Tables } from "@/integrations/supabase/types";

export default function ManageUsersPage() {
  const [users, setUsers] = useState<Tables<"profiles">[]>([]);
  const [roles, setRoles] = useState<Tables<"user_roles">[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    const [u, r] = await Promise.all([getAllUsers(), getUserRoles()]);
    setUsers(u);
    setRoles(r);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const getUserRole = (userId: string) => {
    const userRoles = roles.filter((r) => r.user_id === userId);
    return userRoles.map((r) => r.role);
  };

  const handleToggleAdmin = async (userId: string) => {
    const isCurrentlyAdmin = getUserRole(userId).includes("admin");
    try {
      if (isCurrentlyAdmin) {
        await removeUserRole(userId, "admin");
        toast.success("Admin role removed");
      } else {
        await setUserRole(userId, "admin");
        toast.success("Admin role granted");
      }
      await fetchData();
    } catch (err: any) {
      toast.error(err.message || "Failed to update role");
    }
  };

  const filtered = users.filter((u) =>
    (u.full_name || "").toLowerCase().includes(search.toLowerCase()) ||
    u.user_id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">Manage Users</h1>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input className="pl-10" placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading...</div>
      ) : (
        <Card className="border border-border">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>District</TableHead>
                  <TableHead>Roles</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.full_name || "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{user.phone || "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{user.district || "—"}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {getUserRole(user.user_id).map((role) => (
                          <Badge key={role} variant={role === "admin" ? "default" : "secondary"} className="text-xs">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleAdmin(user.user_id)}
                      >
                        {getUserRole(user.user_id).includes("admin") ? (
                          <><ShieldOff className="h-4 w-4 mr-1" />Remove Admin</>
                        ) : (
                          <><Shield className="h-4 w-4 mr-1" />Make Admin</>
                        )}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
