import { useEffect, useState } from "react";
import { getAllCrimeReports, getAllMissingPersons, getAllMissingProperty, updateCrimeReport, updateMissingPerson, updateMissingProperty } from "@/services/api";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import type { Tables } from "@/integrations/supabase/types";

const statuses = ["pending", "under_review", "investigating", "resolved", "dismissed"] as const;
const statusColors: Record<string, string> = {
  pending: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-primary/10 text-primary border-primary/20",
  investigating: "bg-primary/10 text-primary border-primary/20",
  resolved: "bg-success/10 text-success border-success/20",
  dismissed: "bg-muted text-muted-foreground border-border",
};

export default function AdminReportsPage() {
  const [crimes, setCrimes] = useState<Tables<"crime_reports">[]>([]);
  const [persons, setPersons] = useState<Tables<"missing_persons">[]>([]);
  const [property, setProperty] = useState<Tables<"missing_property">[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const fetchData = async () => {
    const [c, p, pr] = await Promise.all([getAllCrimeReports(), getAllMissingPersons(), getAllMissingProperty()]);
    setCrimes(c);
    setPersons(p);
    setProperty(pr);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleUpdateCrimeStatus = async (id: string, status: string) => {
    try {
      await updateCrimeReport(id, { status: status as any });
      toast.success("Status updated");
      fetchData();
    } catch (err: any) { toast.error(err.message); }
  };

  const handleUpdatePersonStatus = async (id: string, status: string) => {
    try {
      await updateMissingPerson(id, { status: status as any });
      toast.success("Status updated");
      fetchData();
    } catch (err: any) { toast.error(err.message); }
  };

  const handleUpdatePropertyStatus = async (id: string, status: string) => {
    try {
      await updateMissingProperty(id, { status: status as any });
      toast.success("Status updated");
      fetchData();
    } catch (err: any) { toast.error(err.message); }
  };

  const filterItems = <T extends { status: string }>(items: T[]) =>
    filter === "all" ? items : items.filter((i) => i.status === filter);

  if (loading) return <div className="text-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">All Reports</h1>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {statuses.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="crimes">
        <TabsList>
          <TabsTrigger value="crimes">Crimes ({filterItems(crimes).length})</TabsTrigger>
          <TabsTrigger value="persons">Missing Persons ({filterItems(persons).length})</TabsTrigger>
          <TabsTrigger value="property">Missing Property ({filterItems(property).length})</TabsTrigger>
        </TabsList>

        <TabsContent value="crimes" className="space-y-3 mt-4">
          {filterItems(crimes).map((c) => (
            <Card key={c.id} className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{c.crime_type}</h3>
                      <Badge variant="outline" className={statusColors[c.status]}>{c.status.replace("_", " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{c.description}</p>
                    <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Ref: {c.reference_number}</span>
                      {c.district && <span>{c.district}</span>}
                      <span>{new Date(c.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Select value={c.status} onValueChange={(v) => handleUpdateCrimeStatus(c.id, v)}>
                    <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="persons" className="space-y-3 mt-4">
          {filterItems(persons).map((p) => (
            <Card key={p.id} className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{p.full_name}</h3>
                      <Badge variant="outline" className={statusColors[p.status]}>{p.status.replace("_", " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{p.description}</p>
                    <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Ref: {p.reference_number}</span>
                      {p.district && <span>{p.district}</span>}
                    </div>
                  </div>
                  <Select value={p.status} onValueChange={(v) => handleUpdatePersonStatus(p.id, v)}>
                    <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="property" className="space-y-3 mt-4">
          {filterItems(property).map((p) => (
            <Card key={p.id} className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{p.item_type}</h3>
                      <Badge variant="outline" className={statusColors[p.status]}>{p.status.replace("_", " ")}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{p.item_description}</p>
                    <span className="text-xs text-muted-foreground">Ref: {p.reference_number}</span>
                  </div>
                  <Select value={p.status} onValueChange={(v) => handleUpdatePropertyStatus(p.id, v)}>
                    <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
