import { useEffect, useState } from "react";
import { getAllCrimeReports, getAllMissingPersons, getAllMissingProperty, getAllUsers, getReportStats } from "@/services/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { FileText, Users, Package, UserCheck, ArrowRight } from "lucide-react";

export default function AdminDashboardPage() {
  const [stats, setStats] = useState({ totalCrimeReports: 0, totalMissingPersons: 0, totalMissingProperty: 0 });
  const [userCount, setUserCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      getReportStats(),
      getAllUsers(),
    ]).then(([s, users]) => {
      setStats(s);
      setUserCount(users.length);
    }).finally(() => setLoading(false));
  }, []);

  const cards = [
    { title: "Crime Reports", count: stats.totalCrimeReports, icon: FileText, path: "/admin/reports", color: "text-destructive" },
    { title: "Missing Persons", count: stats.totalMissingPersons, icon: Users, path: "/admin/reports", color: "text-warning" },
    { title: "Missing Property", count: stats.totalMissingProperty, icon: Package, path: "/admin/reports", color: "text-primary" },
    { title: "Registered Users", count: userCount, icon: UserCheck, path: "/admin/users", color: "text-success" },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">Admin Dashboard</h1>
      {loading ? (
        <div className="text-center py-12 text-muted-foreground">Loading...</div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {cards.map((card) => {
              const Icon = card.icon;
              return (
                <Link key={card.title} to={card.path}>
                  <Card className="border border-border hover:border-primary/20 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <Icon className={`h-5 w-5 ${card.color}`} />
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <p className="text-2xl font-semibold mt-3">{card.count}</p>
                      <p className="text-sm text-muted-foreground">{card.title}</p>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="border border-border">
              <CardHeader><CardTitle className="text-base">Quick Actions</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                <Link to="/admin/users" className="flex items-center justify-between p-3 rounded-md hover:bg-muted transition-colors">
                  <span className="text-sm font-medium">Manage Users</span><ArrowRight className="h-4 w-4 text-muted-foreground" />
                </Link>
                <Link to="/admin/pending" className="flex items-center justify-between p-3 rounded-md hover:bg-muted transition-colors">
                  <span className="text-sm font-medium">Review Pending Reports</span><ArrowRight className="h-4 w-4 text-muted-foreground" />
                </Link>
                <Link to="/admin/reports" className="flex items-center justify-between p-3 rounded-md hover:bg-muted transition-colors">
                  <span className="text-sm font-medium">All Reports Dashboard</span><ArrowRight className="h-4 w-4 text-muted-foreground" />
                </Link>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
