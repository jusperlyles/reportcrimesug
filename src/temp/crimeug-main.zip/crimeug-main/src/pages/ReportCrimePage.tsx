import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useI18n } from "@/contexts/I18nContext";
import { createCrimeReport, uploadFile } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

const crimeTypes = [
  "Theft", "Robbery", "Assault", "Fraud", "Burglary", "Cybercrime",
  "Domestic Violence", "Drug Offense", "Murder", "Kidnapping",
  "Corruption", "Traffic Offense", "Other"
];

const districts = [
  "Kampala", "Wakiso", "Mukono", "Jinja", "Mbale", "Gulu",
  "Mbarara", "Fort Portal", "Lira", "Soroti", "Masaka", "Entebbe"
];

export default function ReportCrimePage() {
  const { user } = useAuth();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    crime_type: "",
    description: "",
    location: "",
    district: "",
    date_of_incident: "",
    is_anonymous: false,
  });
  const [files, setFiles] = useState<File[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      let mediaUrls: string[] = [];
      for (const file of files) {
        const url = await uploadFile("evidence", `${user.id}/${Date.now()}-${file.name}`, file);
        mediaUrls.push(url);
      }
      await createCrimeReport({
        ...form,
        user_id: user.id,
        date_of_incident: form.date_of_incident || null,
        media_urls: mediaUrls.length > 0 ? mediaUrls : null,
      });
      toast.success("Crime report submitted successfully!");
      navigate("/my-reports");
    } catch (err: any) {
      toast.error(err.message || "Failed to submit report");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <Card className="border border-border">
        <CardHeader>
          <CardTitle>{t("dashboard.report_crime")}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>{t("report.type")}</Label>
              <Select value={form.crime_type} onValueChange={(v) => setForm({ ...form, crime_type: v })}>
                <SelectTrigger><SelectValue placeholder="Select crime type" /></SelectTrigger>
                <SelectContent>
                  {crimeTypes.map((type) => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("report.description")}</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                required
                rows={4}
                placeholder="Describe what happened..."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t("report.location")}</Label>
                <Input
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  placeholder="Where did it happen?"
                />
              </div>
              <div className="space-y-2">
                <Label>{t("report.district")}</Label>
                <Select value={form.district} onValueChange={(v) => setForm({ ...form, district: v })}>
                  <SelectTrigger><SelectValue placeholder="Select district" /></SelectTrigger>
                  <SelectContent>
                    {districts.map((d) => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>{t("report.date")}</Label>
              <Input
                type="datetime-local"
                value={form.date_of_incident}
                onChange={(e) => setForm({ ...form, date_of_incident: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>{t("report.evidence")}</Label>
              <Input
                type="file"
                multiple
                accept="image/*,video/*,.pdf"
                onChange={(e) => setFiles(Array.from(e.target.files || []))}
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="anonymous"
                checked={form.is_anonymous}
                onCheckedChange={(c) => setForm({ ...form, is_anonymous: c === true })}
              />
              <Label htmlFor="anonymous" className="text-sm">{t("report.anonymous")}</Label>
            </div>
            <Button type="submit" className="w-full" disabled={loading || !form.crime_type || !form.description}>
              {loading ? t("common.loading") : t("report.submit")}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
