import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, MessageCircle, Globe, MapPin } from "lucide-react";

const helpResources = [
  {
    title: "Emergency Services",
    icon: Phone,
    items: [
      { label: "Police Emergency", value: "999", link: "tel:999" },
      { label: "Ambulance", value: "911", link: "tel:911" },
      { label: "Fire Brigade", value: "112", link: "tel:112" },
    ],
  },
  {
    title: "Support Hotlines",
    icon: MessageCircle,
    items: [
      { label: "Child Helpline", value: "116", link: "tel:116" },
      { label: "GBV Hotline", value: "0800-111-222", link: "tel:0800111222" },
      { label: "Mental Health", value: "+256-414-270-587", link: "tel:+256414270587" },
    ],
  },
  {
    title: "Online Resources",
    icon: Globe,
    items: [
      { label: "Uganda Police Force", value: "upf.go.ug", link: "https://upf.go.ug" },
      { label: "Uganda Human Rights Commission", value: "uhrc.ug", link: "https://uhrc.ug" },
      { label: "Legal Aid", value: "laspnet.org", link: "https://laspnet.org" },
    ],
  },
  {
    title: "Visit In Person",
    icon: MapPin,
    items: [
      { label: "Your nearest police station", value: "Find Stations →", link: "/stations" },
      { label: "Uganda Law Society", value: "Plot 5A John Babiiha Ave, Kampala" },
    ],
  },
];

export default function HelpPage() {
  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold">Get Help</h1>
      <p className="text-muted-foreground">Emergency contacts and support resources available to you.</p>
      <div className="grid gap-4 md:grid-cols-2">
        {helpResources.map((section) => {
          const Icon = section.icon;
          return (
            <Card key={section.title} className="border border-border">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Icon className="h-5 w-5 text-primary" />
                  {section.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {section.items.map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{item.label}</span>
                    {item.link ? (
                      <a href={item.link} className="text-sm font-medium text-primary hover:underline">{item.value}</a>
                    ) : (
                      <span className="text-sm text-foreground">{item.value}</span>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
