import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useI18n } from "@/contexts/I18nContext";
import { Card, CardContent } from "@/components/ui/card";
import {
  FileText, Users, Package, MapPin, BarChart3, Phone,
  Scale, HelpCircle
} from "lucide-react";

const dashboardCards = [
  { key: "dashboard.report_crime", path: "/report-crime", icon: FileText, color: "text-destructive" },
  { key: "dashboard.missing_person", path: "/report-missing-person", icon: Users, color: "text-warning" },
  { key: "dashboard.missing_property", path: "/report-missing-property", icon: Package, color: "text-primary" },
  { key: "dashboard.find_station", path: "/stations", icon: MapPin, color: "text-success" },
  { key: "dashboard.view_reports", path: "/my-reports", icon: BarChart3, color: "text-primary" },
  { key: "nav.laws", path: "/laws", icon: Scale, color: "text-muted-foreground" },
  { key: "nav.help", path: "/help", icon: HelpCircle, color: "text-primary" },
];

export default function DashboardPage() {
  const { profile } = useAuth();
  const { t } = useI18n();

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold">{t("dashboard.welcome")}, {profile?.full_name || "User"}</h1>
        <p className="text-muted-foreground mt-1">What would you like to do today?</p>
      </div>

      {/* Emergency banner */}
      <a href="tel:999" className="block">
        <Card className="bg-destructive text-destructive-foreground border-0 hover:opacity-90 transition-opacity">
          <CardContent className="flex items-center gap-3 py-4">
            <Phone className="h-6 w-6" />
            <div>
              <p className="font-semibold">{t("dashboard.emergency")}</p>
              <p className="text-sm opacity-90">For immediate danger, call emergency services</p>
            </div>
          </CardContent>
        </Card>
      </a>

      {/* Action cards grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {dashboardCards.map((card) => {
          const Icon = card.icon;
          return (
            <Link key={card.path} to={card.path}>
              <Card className="h-full border border-border hover:border-primary/30 hover:shadow-sm transition-all cursor-pointer">
                <CardContent className="flex flex-col items-center justify-center text-center py-6 px-4 gap-3">
                  <div className={`h-12 w-12 rounded-lg bg-muted flex items-center justify-center ${card.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium">{t(card.key)}</p>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
