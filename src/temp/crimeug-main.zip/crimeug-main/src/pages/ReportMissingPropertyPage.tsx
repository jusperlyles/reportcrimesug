import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { createMissingProperty, uploadFile } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const itemTypes = ["Phone", "Laptop", "Vehicle", "Motorcycle", "Bicycle", "Jewelry", "Documents", "Money", "Other"];
const districts = ["Kampala", "Wakiso", "Mukono", "Jinja", "Mbale", "Gulu", "Mbarara", "Fort Portal", "Lira", "Soroti", "Masaka", "Entebbe"];

export default function ReportMissingPropertyPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [photo, setPhoto] = useState<File | null>(null);
  const [form, setForm] = useState({
    item_type: "", item_description: "", serial_number: "",
    last_seen_location: "", last_seen_date: "", district: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      let photoUrl: string | null = null;
      if (photo) {
        photoUrl = await uploadFile("evidence", `${user.id}/${Date.now()}-${photo.name}`, photo);
      }
      await createMissingProperty({
        ...form,
        user_id: user.id,
        last_seen_date: form.last_seen_date || null,
        photo_url: photoUrl,
      });
      toast.success("Missing property report submitted!");
      navigate("/my-reports");
    } catch (err: any) {
      toast.error(err.message || "Failed to submit");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <Card className="border border-border">
        <CardHeader><CardTitle>Report Missing Property</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Item Type *</Label>
              <Select value={form.item_type} onValueChange={(v) => setForm({ ...form, item_type: v })}>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>{itemTypes.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Description *</Label>
              <Textarea value={form.item_description} onChange={(e) => setForm({ ...form, item_description: e.target.value })} required rows={3} placeholder="Describe the item..." />
            </div>
            <div className="space-y-2">
              <Label>Serial Number</Label>
              <Input value={form.serial_number} onChange={(e) => setForm({ ...form, serial_number: e.target.value })} placeholder="If applicable" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Last Seen Location</Label>
                <Input value={form.last_seen_location} onChange={(e) => setForm({ ...form, last_seen_location: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>District</Label>
                <Select value={form.district} onValueChange={(v) => setForm({ ...form, district: v })}>
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>{districts.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Last Seen Date</Label>
              <Input type="datetime-local" value={form.last_seen_date} onChange={(e) => setForm({ ...form, last_seen_date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Photo</Label>
              <Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] || null)} />
            </div>
            <Button type="submit" className="w-full" disabled={loading || !form.item_type || !form.item_description}>
              {loading ? "Submitting..." : "Submit Report"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
