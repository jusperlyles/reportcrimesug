import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { I18nProvider } from "@/contexts/I18nContext";
import AppLayout from "@/components/AppLayout";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminRoute from "@/components/AdminRoute";

// Pages
import AuthPage from "@/pages/AuthPage";
import ForgotPasswordPage from "@/pages/ForgotPasswordPage";
import ResetPasswordPage from "@/pages/ResetPasswordPage";
import DashboardPage from "@/pages/DashboardPage";
import ReportCrimePage from "@/pages/ReportCrimePage";
import MissingPersonsPage from "@/pages/MissingPersonsPage";
import ReportMissingPersonPage from "@/pages/ReportMissingPersonPage";
import MissingPropertyPage from "@/pages/MissingPropertyPage";
import ReportMissingPropertyPage from "@/pages/ReportMissingPropertyPage";
import SearchStationsPage from "@/pages/SearchStationsPage";
import MyReportsPage from "@/pages/MyReportsPage";
import LawsPage from "@/pages/LawsPage";
import HelpPage from "@/pages/HelpPage";
import NotificationsPage from "@/pages/NotificationsPage";
import SettingsPage from "@/pages/SettingsPage";
import AdminDashboardPage from "@/pages/AdminDashboardPage";
import ManageUsersPage from "@/pages/ManageUsersPage";
import PendingRequestsPage from "@/pages/PendingRequestsPage";
import AdminReportsPage from "@/pages/AdminReportsPage";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <I18nProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<Navigate to="/auth" replace />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />

              {/* Protected routes with layout */}
              <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
                <Route path="/dashboard" element={<DashboardPage />} />
                <Route path="/report-crime" element={<ReportCrimePage />} />
                <Route path="/missing-persons" element={<MissingPersonsPage />} />
                <Route path="/report-missing-person" element={<ReportMissingPersonPage />} />
                <Route path="/missing-property" element={<MissingPropertyPage />} />
                <Route path="/report-missing-property" element={<ReportMissingPropertyPage />} />
                <Route path="/stations" element={<SearchStationsPage />} />
                <Route path="/my-reports" element={<MyReportsPage />} />
                <Route path="/laws" element={<LawsPage />} />
                <Route path="/help" element={<HelpPage />} />
                <Route path="/notifications" element={<NotificationsPage />} />
                <Route path="/settings" element={<SettingsPage />} />

                {/* Admin routes */}
                <Route path="/admin" element={<AdminRoute><AdminDashboardPage /></AdminRoute>} />
                <Route path="/admin/users" element={<AdminRoute><ManageUsersPage /></AdminRoute>} />
                <Route path="/admin/pending" element={<AdminRoute><PendingRequestsPage /></AdminRoute>} />
                <Route path="/admin/reports" element={<AdminRoute><AdminReportsPage /></AdminRoute>} />
              </Route>

              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </I18nProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
