import { createContext, useContext, useState, ReactNode } from "react";

const translations: Record<string, Record<string, string>> = {
  en: {
    "app.title": "Uganda Police Reporting",
    "nav.home": "Home",
    "nav.report": "Report Crime",
    "nav.missing": "Missing Persons",
    "nav.property": "Lost Property",
    "nav.stations": "Police Stations",
    "nav.laws": "Laws & Rights",
    "nav.help": "Get Help",
    "nav.notifications": "Notifications",
    "nav.settings": "Settings",
    "nav.admin": "Admin Dashboard",
    "nav.reports": "My Reports",
    "nav.logout": "Log Out",
    "nav.login": "Log In",
    "auth.login": "Log In",
    "auth.signup": "Sign Up",
    "auth.email": "Email",
    "auth.password": "Password",
    "auth.fullname": "Full Name",
    "auth.forgot": "Forgot Password?",
    "auth.no_account": "Don't have an account?",
    "auth.has_account": "Already have an account?",
    "auth.reset": "Reset Password",
    "dashboard.welcome": "Welcome back",
    "dashboard.report_crime": "Report a Crime",
    "dashboard.missing_person": "Report Missing Person",
    "dashboard.missing_property": "Report Missing Property",
    "dashboard.find_station": "Find Police Station",
    "dashboard.view_reports": "View My Reports",
    "dashboard.emergency": "Emergency: Call 999",
    "report.type": "Crime Type",
    "report.description": "Description",
    "report.location": "Location",
    "report.district": "District",
    "report.date": "Date of Incident",
    "report.anonymous": "Report Anonymously",
    "report.submit": "Submit Report",
    "report.evidence": "Upload Evidence",
    "status.pending": "Pending",
    "status.under_review": "Under Review",
    "status.investigating": "Investigating",
    "status.resolved": "Resolved",
    "status.dismissed": "Dismissed",
    "admin.dashboard": "Admin Dashboard",
    "admin.users": "Manage Users",
    "admin.admins": "Manage Admins",
    "admin.pending": "Pending Requests",
    "admin.reports": "All Reports",
    "admin.statistics": "Statistics",
    "common.search": "Search...",
    "common.filter": "Filter",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.delete": "Delete",
    "common.edit": "Edit",
    "common.view": "View",
    "common.loading": "Loading...",
    "common.no_results": "No results found",
    "common.back": "Back",
  },
  sw: {
    "app.title": "Ripoti ya Polisi Uganda",
    "nav.home": "Nyumbani",
    "nav.report": "Ripoti Uhalifu",
    "nav.missing": "Watu Waliopotea",
    "nav.property": "Mali Iliyopotea",
    "nav.stations": "Vituo vya Polisi",
    "nav.laws": "Sheria na Haki",
    "nav.help": "Pata Msaada",
    "nav.notifications": "Arifa",
    "nav.settings": "Mipangilio",
    "nav.admin": "Dashibodi ya Msimamizi",
    "nav.reports": "Ripoti Zangu",
    "nav.logout": "Toka",
    "nav.login": "Ingia",
    "auth.login": "Ingia",
    "auth.signup": "Jisajili",
    "auth.email": "Barua pepe",
    "auth.password": "Nywila",
    "auth.fullname": "Jina Kamili",
    "dashboard.welcome": "Karibu tena",
    "dashboard.report_crime": "Ripoti Uhalifu",
    "dashboard.missing_person": "Ripoti Mtu Aliyepotea",
    "dashboard.missing_property": "Ripoti Mali Iliyopotea",
    "dashboard.find_station": "Tafuta Kituo cha Polisi",
    "common.search": "Tafuta...",
    "common.save": "Hifadhi",
    "common.cancel": "Ghairi",
    "common.loading": "Inapakia...",
  },
  lg: {
    "app.title": "Uganda Police Reporting",
    "nav.home": "Awaka",
    "nav.report": "Loopa Omusango",
    "nav.missing": "Abantu Ababuze",
    "nav.stations": "Sitesoni za Poliisi",
    "nav.help": "Funa Obuyambi",
    "nav.settings": "Entegeka",
    "nav.logout": "Vaayo",
    "nav.login": "Yingira",
    "auth.login": "Yingira",
    "auth.signup": "Wandiikibwe",
    "dashboard.welcome": "Tukusanyukidde",
    "common.search": "Noonya...",
    "common.loading": "Kitikka...",
  },
};

interface I18nContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  availableLanguages: { code: string; name: string }[];
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

const availableLanguages = [
  { code: "en", name: "English" },
  { code: "sw", name: "Kiswahili" },
  { code: "lg", name: "Luganda" },
];

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState(
    () => localStorage.getItem("app-language") || "en"
  );

  const handleSetLanguage = (lang: string) => {
    setLanguage(lang);
    localStorage.setItem("app-language", lang);
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || translations["en"]?.[key] || key;
  };

  return (
    <I18nContext.Provider
      value={{ language, setLanguage: handleSetLanguage, t, availableLanguages }}
    >
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) throw new Error("useI18n must be used within I18nProvider");
  return context;
}
