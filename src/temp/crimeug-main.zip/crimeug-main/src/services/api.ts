import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";

// ===== CRIME REPORTS =====
export async function getCrimeReports(userId?: string) {
  let query = supabase.from("crime_reports").select("*").order("created_at", { ascending: false });
  if (userId) query = query.eq("user_id", userId);
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export async function getCrimeReport(id: string) {
  const { data, error } = await supabase.from("crime_reports").select("*").eq("id", id).single();
  if (error) throw error;
  return data;
}

export async function createCrimeReport(report: TablesInsert<"crime_reports">) {
  const { data, error } = await supabase.from("crime_reports").insert(report).select().single();
  if (error) throw error;
  return data;
}

export async function updateCrimeReport(id: string, updates: TablesUpdate<"crime_reports">) {
  const { data, error } = await supabase.from("crime_reports").update(updates).eq("id", id).select().single();
  if (error) throw error;
  return data;
}

// ===== MISSING PERSONS =====
export async function getMissingPersons() {
  const { data, error } = await supabase.from("missing_persons").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function createMissingPerson(report: TablesInsert<"missing_persons">) {
  const { data, error } = await supabase.from("missing_persons").insert(report).select().single();
  if (error) throw error;
  return data;
}

export async function updateMissingPerson(id: string, updates: TablesUpdate<"missing_persons">) {
  const { data, error } = await supabase.from("missing_persons").update(updates).eq("id", id).select().single();
  if (error) throw error;
  return data;
}

// ===== MISSING PROPERTY =====
export async function getMissingProperty() {
  const { data, error } = await supabase.from("missing_property").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function createMissingProperty(report: TablesInsert<"missing_property">) {
  const { data, error } = await supabase.from("missing_property").insert(report).select().single();
  if (error) throw error;
  return data;
}

export async function updateMissingProperty(id: string, updates: TablesUpdate<"missing_property">) {
  const { data, error } = await supabase.from("missing_property").update(updates).eq("id", id).select().single();
  if (error) throw error;
  return data;
}

// ===== POLICE STATIONS =====
export async function getPoliceStations(search?: string) {
  let query = supabase.from("police_stations").select("*").order("name");
  if (search) {
    query = query.or(`name.ilike.%${search}%,district.ilike.%${search}%,region.ilike.%${search}%`);
  }
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

// ===== NOTIFICATIONS =====
export async function getNotifications(userId: string) {
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function markNotificationRead(id: string) {
  const { error } = await supabase.from("notifications").update({ is_read: true }).eq("id", id);
  if (error) throw error;
}

export async function markAllNotificationsRead(userId: string) {
  const { error } = await supabase.from("notifications").update({ is_read: true }).eq("user_id", userId).eq("is_read", false);
  if (error) throw error;
}

// ===== PROFILES =====
export async function getProfile(userId: string) {
  const { data, error } = await supabase.from("profiles").select("*").eq("user_id", userId).single();
  if (error) throw error;
  return data;
}

export async function updateProfile(userId: string, updates: TablesUpdate<"profiles">) {
  const { data, error } = await supabase.from("profiles").update(updates).eq("user_id", userId).select().single();
  if (error) throw error;
  return data;
}

// ===== ADMIN =====
export async function getAllUsers() {
  const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function getAllCrimeReports() {
  const { data, error } = await supabase.from("crime_reports").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function getAllMissingPersons() {
  const { data, error } = await supabase.from("missing_persons").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function getAllMissingProperty() {
  const { data, error } = await supabase.from("missing_property").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function getUserRoles() {
  const { data, error } = await supabase.from("user_roles").select("*");
  if (error) throw error;
  return data;
}

export async function setUserRole(userId: string, role: "admin" | "moderator" | "user") {
  const { data: existing } = await supabase.from("user_roles").select("*").eq("user_id", userId).eq("role", role);
  if (existing && existing.length > 0) return existing[0];
  
  const { data, error } = await supabase.from("user_roles").insert({ user_id: userId, role }).select().single();
  if (error) throw error;
  return data;
}

export async function removeUserRole(userId: string, role: "admin" | "moderator" | "user") {
  const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
  if (error) throw error;
}

// ===== MEDIA UPLOAD =====
export async function uploadFile(bucket: string, path: string, file: File) {
  const { data, error } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
  if (error) throw error;
  const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);
  return urlData.publicUrl;
}

// ===== STATS =====
export async function getReportStats() {
  const [crimes, persons, property] = await Promise.all([
    supabase.from("crime_reports").select("status", { count: "exact" }),
    supabase.from("missing_persons").select("status", { count: "exact" }),
    supabase.from("missing_property").select("status", { count: "exact" }),
  ]);
  
  return {
    totalCrimeReports: crimes.count || 0,
    totalMissingPersons: persons.count || 0,
    totalMissingProperty: property.count || 0,
  };
}
